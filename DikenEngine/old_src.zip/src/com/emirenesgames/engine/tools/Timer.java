package com.emirenesgames.engine.tools;

public class Timer {
	private Runnable runnable;
	private long delay, maxDelay;
	
	public Timer(Runnable runnable, long delay) {
		this.runnable = runnable;
		this.maxDelay = delay;
	}
	
	public void start() {
		new Thread(() -> {
			while (delay < maxDelay) {
				runnable.run();
				delay += 1;
				try {
					Thread.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}).start();
	}
	
	public void startNonThread() {
		while (delay < maxDelay) {
			runnable.run();
			delay += 1;
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
