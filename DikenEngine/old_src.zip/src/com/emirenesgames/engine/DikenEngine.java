package com.emirenesgames.engine;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.lwjgl.BufferUtils;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Cursor;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import static org.lwjgl.opengl.GL11.*;

import com.emirenesgames.engine.console.Command;
import com.emirenesgames.engine.console.Console;
import com.emirenesgames.engine.game.World;
import com.emirenesgames.engine.gui.ConsoleScreen;
import com.emirenesgames.engine.gui.CrashScreen;
import com.emirenesgames.engine.gui.Screen;
import com.emirenesgames.engine.gui.Text;
import com.emirenesgames.engine.gui.UniFont;
import com.emirenesgames.engine.gui.window.WindowManager;
import com.emirenesgames.engine.nativeman.NativeManager;
import com.emirenesgames.engine.resource.Bitmap;
import com.emirenesgames.engine.resource.EnumResource;
import com.emirenesgames.engine.resource.IOResource;
import com.emirenesgames.engine.resource.IResource;
import com.emirenesgames.engine.resource.ResourceLocator;

/**
 * DikenEngine, Oyun Motorunun Temel Ayarlarınon Değiştirildiği Sınıftır.
 **/
public class DikenEngine implements Runnable {
	/** Oyun Motorun Genişliği **/
	public static int WIDTH = 320;
	
	/** Oyun Motorun Yüksekliği **/
	public static int HEIGHT = 240;
	
	/** Çizerken Boyutlandırma Yapar **/
	public static int SCALE = 3;
	
	private int tmpW, tmpH;
	
	/** Motor Sürümü **/
	public static final String VERSION = "v0.7.1";

	/** Hedef FPS **/
	public long TARGET_FPS = 60;

	/** Şu Anki Ekran **/
	public Screen currentScreen;

	/** Oyun Motorun Varsayılan Yazı Tipi **/
	public UniFont defaultFont;
	
	/** DikenEngine.getEngine() için **/
	private static DikenEngine instance;
	
	/** Ekran Bitmap'i **/
	private Bitmap screenBitmap;

	/** Oyun Motoru Çalışma Durumu **/
	private boolean running;

	public int fps;

	/** Oyun Yöneticisi **/
	public GameManager gManager;

	private Thread engineThread;

	private boolean fullscreen = false;

	/** Fare Resmi **/
	public Bitmap cursorBitmap;

	/** Resim **/
	private volatile BufferedImage screenImage;
	private Init init;
	
	/** Debug **/
	private String[] debug = new String[32000];

	public WindowManager wManager;
	
	/** Dünya Sınıfı **/
	public World world;
	
	/** initEngine Kullanılmalıdır **/
	private DikenEngine() {
	}
	
	public void addInit(Init init) {
		this.init = init;
	}

	public void run() {
	    try {
	        this.init();
	        long targetFrameTime = 1000000000L / TARGET_FPS; // Time per frame in nanoseconds
	        long fixedUpdateTime = 1000000000L / 60; // Fixed update rate at 60Hz
	        long lastRenderTime = System.nanoTime();
	        long lastUpdateTime = System.nanoTime();
	        long timer = System.currentTimeMillis();
	        int frames = 0;
	        double accumulator = 0;

	        while(running) {
	        	if (Display.isCloseRequested()) {
	        		stop();
	        		return;
	        	}	        
	        	
	        	targetFrameTime = 1000000000L / TARGET_FPS; // Time per frame in nanoseconds
	            long currentTime = System.nanoTime();
	            
	            // Frame time for rendering
	            long frameTimeDelta = currentTime - lastRenderTime;
	            
	            // Handling variable frame rate rendering
	            if(frameTimeDelta >= targetFrameTime) {
	                lastRenderTime = currentTime;
	                
	                // Update mouse input on every frame
	                
	                //TODO mouse = input.updateMouseStatus(SCALE);
	                
	                // Time since last game logic update
	                long updateDelta = currentTime - lastUpdateTime;
	                accumulator += updateDelta;
	                lastUpdateTime = currentTime;
	                
	                // Run game logic at a fixed rate (60 times per second)
	                while(accumulator >= fixedUpdateTime) {
	                    tick();
	                    accumulator -= fixedUpdateTime;
	                }
	                
	                // Render at the target frame rate
	                render(screenBitmap);
	                frames++;
	                
	                if(Boolean.parseBoolean(gManager.config.getProperty("sync"))) {
	                	Display.sync(60); // Sync to 60 FPS
	                } else {
	                	Display.sync((int) TARGET_FPS); // No sync
	                }
	                
	                // FPS calculation
	                if(System.currentTimeMillis() - timer > 1000) {
	                    fps = frames;
	                    frames = 0;
	                    timer += 1000;
	                }
	                
	                ByteBuffer buffer = BufferUtils.createByteBuffer(WIDTH * HEIGHT * 4);
	                for (int i = 0; i < screenBitmap.pixels.length; i++) {
	                    int pixel = screenBitmap.pixels[i];
	                    buffer.put((byte) ((pixel >> 16) & 0xFF)); // Red
	                    buffer.put((byte) ((pixel >> 8) & 0xFF));  // Green 
	                    buffer.put((byte) (pixel & 0xFF));         // Blue
	                    buffer.put((byte) ((pixel >> 24) & 0xFF)); // Alpha
	                }
	                buffer.flip();
	                
	                // Draw the texture
	                glDrawPixels(WIDTH, HEIGHT, GL_RGBA, GL_UNSIGNED_BYTE, buffer);
	                
	                glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, WIDTH, HEIGHT, 
	                         0, GL_RGBA, GL_UNSIGNED_BYTE, buffer);
	                
	                Display.update();
	            }
	            
	            // Sleep to save CPU
	            long sleepTime = (lastRenderTime - System.nanoTime() + targetFrameTime) / 1000000;
	            if(sleepTime > 0) {
	                Thread.sleep(sleepTime);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        this.crashScreen(e);
	    }
	}
	
	/** Çizme Method'u **/
	private void render(Bitmap screen) {
		try {
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);	
			
			if(currentScreen != null) {
				currentScreen.render(screen);
			}
			wManager.render(screen);
			if(gManager.config.getProperty("show_fps").equals("true") && !gManager.config.getProperty("debug").equals("true")) {
				Text.render("FPS: " + fps, screen, 0, 0);
			}
			if(gManager.config.getProperty("debug").equals("true") && !(this.currentScreen instanceof ConsoleScreen)) {
				for(int i = 0; i < debug.length; i++) {
					String string = debug[i];
					if(string != null) {
						screen.fill(1, 1 + (i * Text.stringBitmapAverageHeight(string, defaultFont)),
								1 + Text.stringBitmapWidth(string, defaultFont),
								1 + (i * Text.stringBitmapAverageHeight(string, defaultFont) + Text.stringBitmapAverageHeight(string, defaultFont)),
								0xff000000);
						Text.render(string, screen, 2, 2 + (i * Text.stringBitmapAverageHeight(string, defaultFont)));
					}
				}
			}
			if(gManager.cursorShowType == 1 && cursorBitmap != null) {
				screen.draw(cursorBitmap, Mouse.getDX() - 1, Mouse.getDY() - 1);
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.crashScreen(e);
		}	
	}

	/** 60 Kere Çakışır **/
	private void tick() {
		try {
			tickDimension();
			debug[1] = "FPS: " + fps;
			debug[2] = "Mouse X: " + Mouse.getDX();
			debug[3] = "Mouse Y: " + Mouse.getDY();
			debug[4] = "Total Vitual Window: " + wManager.size();
			debug[5] = "Java " + Runtime.version().toString();
			debug[6] = "Available processors (cores): " +  Runtime.getRuntime().availableProcessors();
			long var39 = Runtime.getRuntime().maxMemory();
            long var37 = Runtime.getRuntime().totalMemory();
            long var41 = Runtime.getRuntime().freeMemory();
            long var44 = var37 - var41;
			String var45 = "Used memory: " + var44 * 100L / var39 + "% (" + var44 / 1024L / 1024L + "MB) of " + var39 / 1024L / 1024L + "MB";
			debug[8] = var45;
            var45 = "Allocated memory: " + var37 * 100L / var39 + "% (" + var37 / 1024L / 1024L + "MB)";
			debug[9] = var45;
			
			if(this.fullscreen != Boolean.parseBoolean(gManager.config.getProperty("fullscreen"))) {
				this.fullscreen = Boolean.parseBoolean(gManager.config.getProperty("fullscreen"));
	   		  
	   		    if(this.fullscreen) {
	   		    	this.tmpW = WIDTH;
	   		    	this.tmpH = HEIGHT;
	   		    	Display.setFullscreen(true);
	   				//engineWindow.requestFocus();
	   		    } else {
	   		    	Display.setFullscreen(false);
	   		    	Display.setDisplayMode(new DisplayMode(tmpW * SCALE, tmpH * SCALE));
	   		    	//engineWindow.setVisible(true);
	   				//engineWindow.requestFocus();
	   		    }
			}
			if(Display.getTitle() != gManager.config.getProperty("title")) {
				Display.setTitle(gManager.config.getProperty("title"));
		   	}
	   		/*if(input.keysDown[KeyEvent.VK_F11]) {
	   			input.keysDown[KeyEvent.VK_F11] = false;
	   		  	gManager.config.setProperty("fullscreen", "" + (!Boolean.parseBoolean(gManager.config.getProperty("fullscreen"))));
	   		}
	   		if(input.keysDown[KeyEvent.VK_END] && gManager.config.getProperty("console").equals("true") && !(this.currentScreen instanceof ConsoleScreen)) {
	   			input.keysDown[KeyEvent.VK_END] = false;
	   			this.setCurrentScreen(new ConsoleScreen(this.currentScreen));
	   	  	}*/
	   		Language lang = Language.i;
	   		if(lang.selectedLanguage != gManager.config.getProperty("lang")) {
	   			lang.setDefaultLang(gManager.config.getProperty("lang"));
	   		}
	   		wManager.tick();
	   		if(currentScreen != null) {
	   			currentScreen.keyboardEvent();
	   			currentScreen.mouseEvent();
	   			currentScreen.width = DikenEngine.WIDTH;
	   			currentScreen.height = DikenEngine.HEIGHT;
				currentScreen.tick();
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.crashScreen(e);
		}
	}

	/** Oyun Motorunun Araçlarını Ayarlamaları Yapar **/
	private void init() {
		try {
			Display.setDisplayMode(new DisplayMode(WIDTH * SCALE, HEIGHT * SCALE));
			Display.setTitle(gManager.config.getProperty("title"));
			Display.create();
			
			Keyboard.create();
			Mouse.create();
			
			glMatrixMode(GL_PROJECTION);
	        glLoadIdentity();
	        glOrtho(0, WIDTH * SCALE, HEIGHT * SCALE, 0, 1, -1);
	        glMatrixMode(GL_MODELVIEW);
			
		} catch (LWJGLException e) {
			System.err.println("HATA: LWJGL Ekran Modu Ayarlanamadı.");
			e.printStackTrace();
		}
		
		if (init != null) {
			init.loadNatives();
		}
		
		Art.init();
		loadResources();
		if (init != null) {
			init.loadResource();
		}
		
		UniFont.createFont("default_font");
		UniFont.createFont(new Font(Font.DIALOG, Font.PLAIN, 12));
		
		if (init != null) {
			init.fontLoadBefore();
		}
		
		this.defaultFont = UniFont.getFont("Dialog.plain.12");
		
		new Thread(new Runnable() {
			
			public void run() {
				gManager.openLoadingScreen();
				
				UniFont.createFont(new Font(Font.DIALOG, Font.BOLD, 12));
				UniFont.createFont(new Font(Font.DIALOG, Font.ITALIC, 12));
				UniFont.createFont(new Font(Font.DIALOG, Font.BOLD | Font.ITALIC, 12));
				UniFont.createFont(new Font(Font.DIALOG, Font.BOLD, 24));
				
				UniFont.createFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
				UniFont.createFont(new Font(Font.MONOSPACED, Font.BOLD, 12));
				UniFont.createFont(new Font(Font.MONOSPACED, Font.ITALIC, 12));
				UniFont.createFont(new Font(Font.MONOSPACED, Font.BOLD | Font.ITALIC, 12));
				
				UniFont.createFont(new Font(Font.DIALOG_INPUT, Font.PLAIN, 12));
				UniFont.createFont(new Font(Font.DIALOG_INPUT, Font.BOLD, 12));
				UniFont.createFont(new Font(Font.DIALOG_INPUT, Font.ITALIC, 12));
				UniFont.createFont(new Font(Font.DIALOG_INPUT, Font.BOLD | Font.ITALIC, 12));
				
				UniFont.createFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
				UniFont.createFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
				UniFont.createFont(new Font(Font.SANS_SERIF, Font.ITALIC, 12));
				UniFont.createFont(new Font(Font.SANS_SERIF, Font.BOLD | Font.ITALIC, 12));
				
				UniFont.createFont(new Font(Font.SERIF, Font.PLAIN, 12));
				UniFont.createFont(new Font(Font.SERIF, Font.BOLD, 12));
				UniFont.createFont(new Font(Font.SERIF, Font.ITALIC, 12));
				UniFont.createFont(new Font(Font.SERIF, Font.BOLD | Font.ITALIC, 12));
				
				if (init != null) {
					init.fontLoad();
				}
				
				System.out.println("Yazı Tipi Yükleme Tamamlandı!");
				DikenEngine.this.defaultFont = UniFont.getFont("default_font");
				
				gManager.openMainMenu();
			}
			
		}, "Custom Font Load").start();
		
		if (init != null) {
			init.fontLoadAfter();
		}

		Command.initCommands();
		
		cursorBitmap = Art.i.cursors[0][1];
		
		this.screenImage = new BufferedImage(DikenEngine.WIDTH, DikenEngine.HEIGHT, 2);
	    this.screenBitmap = new Bitmap(screenImage);
		
		//TODO this.mouse = this.input.updateMouseStatus(SCALE);		
		this.wManager = new WindowManager();
		
		//TODO if (gManager.cursorShowType != 2) {Mouse.setNativeCursor()}
		
		Console.println("DikenEngine [" + DikenEngine.VERSION + "]");
	    Console.println("Java: " + getJavaVersion());
	    
	    debug[0] = "DikenEngine [" + DikenEngine.VERSION + "]";
	      
	    if(getJavaVersion() < 9) {
	    	Console.println("Java 8 ve altı çalıştırılması önerilmez.");
	    }
	    
	    world = new World();
	    
	    if (init != null) {
			init.systemInited();
		}
	}

	private static void loadLocalNatives() {
		try {
			GetOS.Arch arch = getPCArch();
			
			if(arch == GetOS.Arch.x86) {
				// Linux için
				NativeManager.loadLibraryFromOSPathFromJar("/libjinput-linux.so");
				NativeManager.loadLibraryFromOSPathFromJar("/liblwjgl.so");
				NativeManager.loadLibraryFromOSPathFromJar("/libopenal.so");
				
				// MacOS için
				NativeManager.loadLibraryFromOSPathFromJar("/libjinput-osx.dylib");
				NativeManager.loadLibraryFromOSPathFromJar("/liblwjgl.dylib");
				NativeManager.loadLibraryFromOSPathFromJar("/openal.dylib");
				
				// Windows için
				NativeManager.loadLibraryFromOSPathFromJar("/jinput-dx8.dll");
				NativeManager.loadLibraryFromOSPathFromJar("/jinput-raw.dll");
				NativeManager.loadLibraryFromOSPathFromJar("/lwjgl.dll");
				NativeManager.loadLibraryFromOSPathFromJar("/OpenAL32.dll");
			} else if (arch == GetOS.Arch.x64) {
				// Linux için
				NativeManager.loadLibraryFromOSPathFromJar("/libjinput-linux64.so");
			    NativeManager.loadLibraryFromOSPathFromJar("/liblwjgl64.so");
			    NativeManager.loadLibraryFromOSPathFromJar("/libopenal64.so");
				
				// MacOS için
			    // MacOS için 64 bit mimari desteği yok
				
				// Windows için
			    NativeManager.loadLibraryFromOSPathFromJar("/jinput-dx8_64.dll");
			    NativeManager.loadLibraryFromOSPathFromJar("/jinput-raw_64.dll");
			    NativeManager.loadLibraryFromOSPathFromJar("/lwjgl64.dll");
			    NativeManager.loadLibraryFromOSPathFromJar("/OpenAL64.dll");
			    
			} else {
				System.err.println("HATA: Bilgisayarınızın mimarisi desteklenmiyor. Mimari: " + arch.name());
				System.exit(0);
			}
			
			NativeManager.loadedNativeSetProperty("org.lwjgl.librarypath");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static GetOS.Arch getPCArch() {
		return GetOS.getArch();
	}

	private void loadResources() {
		IResource logo_x32 = IOResource.loadResource(DikenEngine.class.getResourceAsStream("/icon-x16.png"), EnumResource.IMAGE);
		ResourceLocator.addResource(logo_x32, "icon_x16");
	}

	private static int getJavaVersion() {
	    String version = System.getProperty("java.version");
	    if(version.startsWith("1.")) {
	        version = version.substring(2, 3);
	    } else {
	        int dot = version.indexOf(".");
	        if(dot != -1) { version = version.substring(0, dot); }
	    } return Integer.parseInt(version);
	}

	/** Oyun Motorunu Ayarlarını Sağlar **/
	public static DikenEngine initEngine(int width, int height, int scale, String title) {
		DikenEngine.WIDTH = width;
		DikenEngine.HEIGHT = height;
		DikenEngine.SCALE = scale;
		
		if(title == null) {
			title = "Untitled Game";
		}
		
		DikenEngine engine = new DikenEngine();
		engine.screenBitmap = new Bitmap(WIDTH, HEIGHT);
		DikenEngine.instance = engine;
		
		DikenEngine.instance.gManager = new GameManager();
		DikenEngine.instance.gManager.config.setProperty("title", title);	
		DikenEngine.instance = engine;
		
		return DikenEngine.instance;
	}
	
	/** Boyutlandırılabilir Ekranlarda Büyütürken Bitmap'de Büyüyüp Küçülür **/
	public void tickDimension() {
		int newWidth = Display.getWidth();
		int newHeight = Display.getHeight();
		   
		Dimension d = new Dimension(newWidth / DikenEngine.SCALE, newHeight / DikenEngine.SCALE);
			   
	    DikenEngine.WIDTH = (int) (d.getSize().getWidth());
		DikenEngine.HEIGHT = (int) (d.getSize().getHeight());
			   
		if(screenImage == null) return;
			   
		if(screenImage.getWidth() != d.getSize().getWidth() || screenImage.getHeight() != d.getSize().getHeight()) {
			screenImage = new BufferedImage(DikenEngine.WIDTH, DikenEngine.HEIGHT, 2);
			screenBitmap = new Bitmap(screenImage);
				   
			if(currentScreen != null) {
			   setCurrentScreen(DikenEngine.getEngine().currentScreen);
			}
		}
		   
		   
	}
	
	/** Oyun Motorunu Başlatır **/
	public void startEngine() {
		engineThread = new Thread(this, "Engine Loop Thread");
		
		if(engineThread.isAlive()) {
			System.err.println("HATA: Zaten Motor Çalışıyor.");
			return;
		}
		running = true;
		engineThread.start();
	}

	/** Oyun Motorunu Elde Edilmesini Sağlar **/
	public static DikenEngine getEngine() {
		return DikenEngine.instance;
	}

	/** Ekranı Değiştirir **/
	public void setCurrentScreen(Screen screen) {
		  //TODO input.typed = "";
		  if(currentScreen != null) {
			  currentScreen.closeScreen();
		  }
	      this.currentScreen = screen;
	      if (screen != null) {
	         screen.engine = this;
	         screen.openScreen();
	      }

	   }

	public void crashScreen(Exception e) {
		if (this.gManager.config.getProperty("legacy-crash").equals("true")) {
			this.setCurrentScreen(new CrashScreen(e));
		} else {
			StringWriter sWriter = new StringWriter();
			e.printStackTrace(new PrintWriter(sWriter));
			JOptionPane.showMessageDialog(null, "Hata: " + sWriter.toString() + "\n\nLütfen Github'dan Bildiriniz.", "Hata", JOptionPane.ERROR_MESSAGE);
			Display.destroy();
			System.exit(0);
		}
	}

	public void stop() {
		if(currentScreen != null) {
			currentScreen.closeScreen();
		}
		gManager.saveConfig();
		
		Display.destroy();
		this.running = false;
	}
	
	/** Test Kod **/
	public static void main(String[] args) {
		DikenEngine engine = DikenEngine.initEngine(320 * 2, 240 * 2, 2, "Diken Engine " + DikenEngine.VERSION);
		//engine.gManager.setMainMenu(new WorldScreen());
		engine.startEngine();
	}
	
	static {
		loadLocalNatives();
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				try {
					NativeManager.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void windowOpened(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		stop();
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	public void windowActivated(WindowEvent e) {
	}

	public void windowDeactivated(WindowEvent e) {
	}
}
