package com.emirenesgames.engine.gui;

public abstract class LoadingScreen extends Screen {

	public LoadingScreen() {
		// TODO Auto-generated constructor stub
	}

}
