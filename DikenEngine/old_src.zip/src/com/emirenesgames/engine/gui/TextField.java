package com.emirenesgames.engine.gui;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.awt.event.KeyEvent;
import java.io.IOException;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import com.emirenesgames.engine.DikenEngine;
import com.emirenesgames.engine.InputHandler;
import com.emirenesgames.engine.resource.Bitmap;

public class TextField extends GuiObject{
	private static final long serialVersionUID = 1L;
	private boolean isFocused = false;
	public boolean isNumberField = false;
	
	private String text = "";
	private DikenEngine engine;
	
	private int counter;
	
	public TextField(int x, int y, int width, int height, DikenEngine engine) {
		super(x, y, width, height);
		this.engine = engine;
	}
	
	public TextField(String text, int x, int y, int width, int height, DikenEngine engine) {
		this(x, y, width, height, engine);
		this.text = text;
	}
	
	public void tick() {	
		++this.counter;
	}

	public void mouseClicked(int button) {
		if(this.engine.wManager.activeWindow != null && this.engine.wManager.findActiveWindow2(InputHandler.getMousePoint())) {
			if (!this.engine.wManager.activeWindow.guiObjetIsPressed(InputHandler.getMousePoint(), this) && button == 0) {
				this.isFocused = false;
			}
		} else if(!intersects(InputHandler.getMouseHitbox()) && button == 0) {
			this.isFocused = false;
		}
	}

	public void keyPressed(char var1, int var2) {
		UniFont defaultFont = DikenEngine.getEngine().defaultFont;
		if(isFocused) {
			if(InputHandler.isKeyDown(Keyboard.KEY_LCONTROL) && var2 == Keyboard.KEY_V) {
				//this.engine.input.keysDown[KeyEvent.VK_V] = false;
				
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				
				try {
					this.setText(this.getText() + (String) clipboard.getData(DataFlavor.stringFlavor));
				} catch (UnsupportedFlavorException e) {
				} catch (IOException e) {
				}
			}
			if(InputHandler.isKeyDown(Keyboard.KEY_LCONTROL) && var2 == Keyboard.KEY_C) {
				//this.engine.input.keysDown[KeyEvent.VK_C] = false;
				
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(new StringSelection(text), null);

			}
			if(InputHandler.isKeyDown(Keyboard.KEY_LCONTROL) && var2 == Keyboard.KEY_X) {
				//this.engine.input.keysDown[KeyEvent.VK_X] = false;
				
				Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
				clipboard.setContents(new StringSelection(text), null);
				
				this.setText("");
			}
			
			if (InputHandler.isKeyDown(Keyboard.KEY_BACK) && this.text.length() > 0) {
				//this.engine.input.keysDown[KeyEvent.VK_BACK_SPACE] = false;
				text = text.substring(0, text.length() - 1);
			} else {
				if (isNumberField) {
					if(("-0123456789".indexOf(var1) >= 0) && !(Text.stringBitmapWidth(text + var1, defaultFont) > width - Text.stringBitmapWidth("" + var1, defaultFont))) {
						  this.text = this.text + var1;
					}
				} else {
					if((defaultFont.charTypes.indexOf(var1) >= 0) && !(Text.stringBitmapWidth(text + var1, defaultFont) > width - Text.stringBitmapWidth("" + var1, defaultFont))) {
						  this.text = this.text + var1;
					}
				}
				
			}
		}
	}
	
	public Bitmap render() {
		Bitmap bitmap = new Bitmap(this.width + 1, this.height + 1);
		bitmap.box(0, 0, this.width, this.height, isFocused() ? 0xffffff00 : 0xffffffff);
		bitmap.fill(1, 1, this.width - 1, this.height - 1, 0xff282828);
		String text = this.text;
		
		if(isFocused) {
			text = text + (this.counter / 6 % 12 > 6?"_":"");
		}
		Text.render(text, bitmap, 2, 2);
		return bitmap;
	}

	public boolean isFocused() {
		return isFocused;
	}

	public void setFocused(boolean isFocused) {
		this.isFocused = isFocused;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}	
	
	public TextField setNumberic() {
		this.isNumberField = true;
		return this;
	}

}
