package com.emirenesgames.engine.gui;

import com.emirenesgames.engine.resource.Bitmap;

public class WorldScreen extends Screen {

	public void tick() {
		if (engine.world != null) {
			engine.world.tick();
		}
		super.tick();
	}

	public void render(Bitmap screen) {
		if (engine.world != null) {
			engine.world.render(screen);
		}
		super.render(screen);
	}
	
	

}
