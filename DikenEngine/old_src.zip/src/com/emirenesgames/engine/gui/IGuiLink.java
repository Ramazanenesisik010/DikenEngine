package com.emirenesgames.engine.gui;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URI;

public interface IGuiLink {
	void openLink();
	
	default void _openLink(URI uri) {
		if(uri == null) {
			uri = URI.create("about:blank");
		}
		
		try {
			if(Desktop.isDesktopSupported()) {
				Desktop desktop = Desktop.getDesktop();
				desktop.browse(uri);
			}
		} catch (IOException e) {
		}
	}
}
