package com.emirenesgames.engine.gui;

import java.net.URI;

import com.emirenesgames.engine.Art;
import com.emirenesgames.engine.DikenEngine;
import com.emirenesgames.engine.resource.Bitmap;

public class LinkText extends Text implements IGuiLink {
	private static final long serialVersionUID = 1L;
	
	private URI uri;
	
	public LinkText(String text, int x, int y) {
		super(text, x, y, 0xFFFFFFFF, DikenEngine.getEngine().defaultFont);
		this.uri = URI.create("about:blank");
	}
	
	public LinkText(String text, int x, int y, UniFont font) {
		super(text, x, y, 0xFFFFFFFF, font);
		this.uri = URI.create("about:blank");
	}
	
	public LinkText(String text, int x, int y, URI uri, UniFont font) {
		super(text, x, y, 0xffffffff, font);
		this.uri = uri;
	}
	
	public LinkText(String text, int x, int y, URI uri) {
		super(text, x, y, 0xffffffff, DikenEngine.getEngine().defaultFont);
		this.uri = uri;
	}

	public void openLink() {
		this._openLink(uri);
	}

	public Bitmap render() {
		Bitmap bitmap = new Bitmap(width + 9, height);
		bitmap.draw(super.render(), 0, 0);
		bitmap.draw(Art.i.button[3][0], width + 2, height / 2 - 4);
		return bitmap;
	}
}
