package com.emirenesgames.engine.gui;

import java.net.URI;

import com.emirenesgames.engine.Art;
import com.emirenesgames.engine.resource.Bitmap;

public class LinkButton extends Button implements IGuiLink {

	private URI uri;

	public LinkButton(String text, int x, int y, int width, int height, int color, int id) {
		super(text, x, y, width, height, color, id);
	}
	
	public LinkButton(String text, int x, int y, int width, int height, int id) {
		super(text, x, y, width, height, id);
	}
	
	public LinkButton setURI(URI uri) {
		this.uri = uri;
		return this;
	}

	public void openLink() {
		this._openLink(uri);
	}

	public Bitmap render() {
		Bitmap bitmap = super.render();
		bitmap.draw(Art.i.button[3][0], width - 9, height / 2 - 2);
		return bitmap;
	}
}
