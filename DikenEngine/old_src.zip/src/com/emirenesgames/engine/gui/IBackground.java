package com.emirenesgames.engine.gui;

import com.emirenesgames.engine.resource.Bitmap;

public interface IBackground {
	
	void render(Bitmap bitmap);
	
	void tick();

}
