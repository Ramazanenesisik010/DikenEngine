package com.emirenesgames.engine.gui;

import com.emirenesgames.engine.*;
import com.emirenesgames.engine.resource.Bitmap;

import java.util.*;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public abstract class Screen {
   public List<GuiObject> buttons = new ArrayList<GuiObject>();
   public DikenEngine engine;
   
   private IBackground background;
   public int width;
   public int height;

   public void tick() {
	  if(background != null) {
		  background.tick();
	  }
	  
	  for(int i = 0; i < buttons.size(); i++) {
		   GuiObject guiObj = buttons.get(i);
		   guiObj.tick();		      
	   }
   }

   public void render(Bitmap screen) {
	   if(background != null) {
		   background.render(screen);
	   }
	   
       for(int i = 0; i < this.buttons.size(); ++i) {
    	   GuiObject btn = this.buttons.get(i);   
    	   if (btn instanceof Button) {
    		   if(btn.intersects(InputHandler.getMouseHitbox()) && engine.wManager.screenActionMode(InputHandler.getMousePoint())) {
            	   screen.blendDraw(btn.render(), btn.x, btn.y, 0xff0023a6);
               } else if(!btn.active) {
            	   screen.blendDraw(btn.render(), btn.x, btn.y, 0xff000000);
               } else {
            	   screen.draw(btn.render(), btn.x, btn.y);
               }
    	   } else {
        	   screen.draw(btn.render(), btn.x, btn.y);
           }
           
           if(btn instanceof Button) {
        	   Text.renderCenter(((Button)btn).text, screen, btn.x + btn.width / 2, btn.y + ((btn.height / 2) - 4), ((Button)btn).tColor);
           } else if (btn instanceof CheckBox){
        	   Text.render(((CheckBox)btn).text, screen, btn.x + (btn.width + 6), btn.y + ((btn.height / 2) - (8 / 2)));
           }
           
           if (engine.gManager.config.getProperty("debug").equals("true")) {
			   screen.box(btn.x, btn.y, btn.x + btn.width, btn.y + btn.height, 0xff00ff00);
		   }
       }
   }
   
   public void keyPressed(char var1, int key) {
	   for(int i = 0; i < this.buttons.size(); ++i) {
    	   GuiObject btn = ((GuiObject)this.buttons.get(i));
    	   btn.keyPressed(var1, var1);
       }
   }
   
   public void mouseClicked(int x, int y, int button) {
	   for(int i = 0; i < this.buttons.size(); ++i) {
		   GuiObject guiObj = ((GuiObject)this.buttons.get(i));
		   if (engine.wManager.screenActionMode(InputHandler.getMousePoint())) {
			   guiObj.mouseClicked(x, y, button);
			   if(guiObj.intersects(InputHandler.getMouseHitbox()) && button == 0) {
				   //this.engine.input.mb0 = false; 
				   if(guiObj instanceof IGuiLink) {
		        	   ((IGuiLink) guiObj).openLink();
		           } else if(guiObj instanceof Button) {
		               int id = ((Button)guiObj).id;
		               this.actionListener(id);
		               this.actionListener(((Button)guiObj));
		           } else if(guiObj instanceof CheckBox) {
		               ((CheckBox) guiObj).click();
		           } else if(guiObj instanceof TextField) {
		               ((TextField)guiObj).setFocused(!((TextField)guiObj).isFocused());
		           }
			   }
		   }	
	   }
   }
   
   public final void mouseEvent() {
	   if(Mouse.getEventButtonState()) {
		   var var1 = InputHandler.getMouseX();
		   var var2 = InputHandler.getMouseY();
		   this.mouseClicked(var1, var2, Mouse.getEventButton());
	   }
   }

   protected void actionListener(int id) {
   }
   
   protected void actionListener(Button button) {
   }

   public void openScreen() {
   }
   
   public void closeScreen() {
   }
   
   public void setBackground(IBackground var1) {
	   this.background = var1;
   }
   
   public IBackground getBackground() {
	   return this.background;
   }

   public void keyboardEvent() {
	   if(Keyboard.getEventKeyState()) {
		   this.keyPressed(Keyboard.getEventCharacter(), Keyboard.getEventKey());
	   }
   }
}
