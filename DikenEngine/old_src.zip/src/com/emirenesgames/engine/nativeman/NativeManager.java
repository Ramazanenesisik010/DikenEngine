package com.emirenesgames.engine.nativeman;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

import com.emirenesgames.engine.GetOS;

public class NativeManager {
	private static File tempDir;
	
	static {
		try {
			tempDir = Files.createTempDirectory("diken-natives").toFile();
			tempDir.deleteOnExit();
		} catch (IOException e) {
			throw new RuntimeException("Native kütüphaneler için geçici dizin oluşturulamadı", e);
		}
	}
	
	public static void loadLibraryFromJar(String path) throws IOException {
		GetOS.OS os = GetOS.getOS();
		
		path = "/natives/" + path;
		
		if(!path.endsWith(getLibraryExtension(os))) {
			System.out.println("Native kütüphanenin uzantısı uyumsuz: " + path + " != " + getLibraryExtension(os));
			return;
		}
		
        // InputStream ile kaynağı oku
        InputStream in = NativeManager.class.getResourceAsStream(path);
        if (in == null) {
            throw new IOException("Library not found: " + path);
        }
        
        // Dosya uzantısını belirle (Windows: .dll, Linux: .so, Mac: .dylib)
        String libExtension = getLibraryExtension();
        String libName = getLibraryName(path);
        
        if (!getLibraryExtension(os).equals(libExtension)) {
			System.out.println("Native kütüphanenin uzantısı uyumsuz: " + libExtension);
			return;
		}
        
        // Geçici dosya oluştur
        File temp = new File(tempDir, libName + libExtension);
        temp.deleteOnExit();
        
        // InputStream'den geçici dosyaya kopyala
        try (FileOutputStream out = new FileOutputStream(temp)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        } finally {
            in.close();
        }
        
        // Native kütüphaneyi yükle
        System.load(temp.getAbsolutePath());
    }
	
	public static void loadLibraryFromOSPathFromJar(String path) throws IOException {
		GetOS.OS os = GetOS.getOS();
		
		path = "/natives/" + os.name().toLowerCase() + path;
		
		if(!path.endsWith(getLibraryExtension(os))) {
			System.out.println("Native kütüphanenin uzantısı uyumsuz: " + path + " != " + getLibraryExtension(os));
			return;
		}
		
        // InputStream ile kaynağı oku
        InputStream in = NativeManager.class.getResourceAsStream(path);
        if (in == null) {
            throw new IOException("Library not found: " + path);
        }
        
        // Dosya uzantısını belirle (Windows: .dll, Linux: .so, Mac: .dylib)
        String libExtension = getLibraryExtension();
        String libName = getLibraryName(path);
        
        if (!getLibraryExtension(os).equals(libExtension)) {
			System.out.println("Native kütüphanenin uzantısı uyumsuz: " + libExtension);
			return;
		}
        
        // Geçici dosya oluştur
        File temp = new File(tempDir, libName + libExtension);
        temp.deleteOnExit();
        
        // InputStream'den geçici dosyaya kopyala
        try (FileOutputStream out = new FileOutputStream(temp)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = in.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }
        } finally {
            in.close();
        }
        
        // Native kütüphaneyi yükle
        System.load(temp.getAbsolutePath());
    }
	
	public static void loadedNativeSetProperty(String property) {
		System.setProperty(property, tempDir.getAbsolutePath());
	}
    
    private static String getLibraryExtension() {
        GetOS.OS os = GetOS.getOS();
        if (os == GetOS.OS.Windows) {
            return ".dll";
        } else if (os == GetOS.OS.Mac) {
            return ".dylib";
        } else {
            return ".so";
        }
    }
    
    private static String getLibraryExtension(GetOS.OS os) {
        if (os == GetOS.OS.Windows) {
            return ".dll";
        } else if (os == GetOS.OS.Mac) {
            return ".dylib";
        } else {
            return ".so";
        }
    }

    private static String getLibraryName(String path) {
        String[] parts = path.split("/");
        String fileName = parts[parts.length - 1];
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex > 0) ? fileName.substring(0, dotIndex) : fileName;
    }
    
    public static void close() {
    	if(tempDir != null) {
    		System.out.println("Geçici dizin siliniyor: " + tempDir.getAbsolutePath());
    		File[] files = tempDir.listFiles();
    		for (File file : files) {
				if(file != null && file.exists()) {
					System.out.println("Geçici dosya siliniyor: " + file.getAbsolutePath());
					file.delete();
				}
			}
    		tempDir.delete();
		}
    }
}
