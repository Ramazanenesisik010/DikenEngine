package com.emirenesgames.engine;

import java.awt.Canvas;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import com.emirenesgames.engine.gui.Hitbox;

public class InputHandler {
	
	public static int getMouseX() {
		int var1 = Mouse.getEventX();
   		return var1;
	}
	
	public static int getMouseY() {
		int var2 = DikenEngine.HEIGHT - Mouse.getEventY();
   		return var2;
	}
   
	public static Point getMousePoint() {
		int mouseX = getMouseX();
		int mouseY = getMouseY();
		return new Point(mouseX, mouseY);
	}
	
	public static Hitbox getMouseHitbox() {
		int mouseX = getMouseX();
		int mouseY = getMouseY();
		return new Hitbox(mouseX, mouseY, 2, 2);
	}
	
	public static boolean isKeyDown(int lwjglKey) {
		return Keyboard.isKeyDown(lwjglKey);
	}
	
}
