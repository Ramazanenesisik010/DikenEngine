package com.emirenesgames.engine.game;

import com.emirenesgames.engine.gui.Hitbox;
import com.emirenesgames.engine.resource.Bitmap;

public class GameObject extends Hitbox {
	private static final long serialVersionUID = 1L;
	public Bitmap texture;
	public String objectName;
	
	public boolean isRemoved;
	public boolean isGravity = false;
	
	public int fallSpeed = 1;
	
	public GameObject(int x, int y, int width, int height) {
		super(x, y, width, height);
		texture = null;
		objectName = "GameObject"+x+"-"+y+"-"+System.currentTimeMillis();
	}
	
	public GameObject setTexture(Bitmap bitmap) {
		this.texture = bitmap;
		return this;
	}
	
	public GameObject setName(String name) {
		this.objectName = name;
		return this;
	}
	
	public void remove() {
		this.isRemoved = true;
	}
	
	public Bitmap render() {
		Bitmap bitmap = new Bitmap(width, height);
		if(texture != null) {
			bitmap.draw(texture, 0, 0);
		}
		return bitmap;
	}
	
	public void tick() {
		if (isGravity) {
			y+=1;
		}
	}
	
	public void init() {
	}
	
	public void onCollision(GameObject object, World world, boolean isEntity) {
		// Handle collision with another GameObject
	}
	
}
