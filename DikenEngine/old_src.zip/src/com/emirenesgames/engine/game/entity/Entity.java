package com.emirenesgames.engine.game.entity;

import com.emirenesgames.engine.game.GameObject;
import com.emirenesgames.engine.tools.Timer;

public class Entity extends GameObject {
	private static final long serialVersionUID = 1L;
	public int jumpHeight = 1;

	public Entity() {
		super(0, 0, 16, 16);
	}
	
	public void jump() {
		if (!isGravity) {
			return;
		}
		Timer timer = new Timer(() -> {this.y += fallSpeed + jumpHeight;}, 1000);
		timer.start();
	}

}
