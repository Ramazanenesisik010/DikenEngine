package com.emirenesgames.engine.game.entity;

import com.emirenesgames.engine.game.GameObject;
import com.emirenesgames.engine.resource.Bitmap;

public class Player extends Entity {
	private static final long serialVersionUID = 1L;
	
	public Player() {
		super();
		this.setTexture(null);
		this.setName("Player");
		this.isGravity = true;
		this.fallSpeed = 1;
	}	public void jump() {
		if (!isGravity) {
			return;
		}
		this.y -= jumpHeight;
	}	public void move(int dx, int dy) {
		this.x += dx;
		this.y += dy;
	}	public GameObject setTexture(Bitmap bitmap) {
		return super.setTexture(bitmap);
	}	public GameObject setName(String name) {
		return super.setName(name);
	}	public void remove() {
		super.remove();
	}	public Bitmap render() {
		return super.render();
	}	public void tick() {
		super.tick();
	}
}
