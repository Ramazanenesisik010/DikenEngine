package com.emirenesgames.engine.game;

import java.util.ArrayList;
import java.util.List;

import com.emirenesgames.engine.DikenEngine;
import com.emirenesgames.engine.game.entity.Entity;
import com.emirenesgames.engine.resource.Bitmap;

public class World {
	public List<GameObject> gObjects = new ArrayList<>();
	public List<Entity> entities = new ArrayList<>();
	
	public int bgColor = 0xff0000ff;
	
	public World() {
	}
	
	public void addGameObject(GameObject object) {
		object.init();
		gObjects.add(object);
	}
	
	public void removeGameObject(GameObject object) {
		gObjects.remove(object);
	}
	
	public void tick() {
		for (GameObject object : gObjects) {
			if (!object.isRemoved) {
				object.tick();
				//resolveCollision(object);  // Çarpışma çözümlemeyi ekleyin
			}
		}
		
		for (Entity entity : entities) {
		    if (!entity.isRemoved) {
		        entity.tick();
		        resolveCollision(entity);  // Çarpışma çözümlemeyi ekleyin
		    }
		}
		
		for (int i = 0; i < gObjects.size(); i++) {
			GameObject object = gObjects.get(i);
			if (object.isRemoved) {
				gObjects.remove(i);
				i--;
			}
		}
		
		for (int i = 0; i < entities.size(); i++) {
			Entity entity = entities.get(i);
			if (entity.isRemoved) {
				entities.remove(i);
				i--;
			}
		}
	}
	
	public void addEntity(Entity entity) {
		entity.init();
		entities.add(entity);
	}
	
	public void resolveCollision(GameObject entity) {
	    for (GameObject object : gObjects) {
	        if (object == entity || object.isRemoved) continue;

	        float entityLeft = entity.x;
	        float entityRight = entity.x + entity.width;
	        float entityTop = entity.y;
	        float entityBottom = entity.y + entity.height;

	        float objectLeft = object.x;
	        float objectRight = object.x + object.width;
	        float objectTop = object.y;
	        float objectBottom = object.y + object.height;

	        if (entityRight > objectLeft && entityLeft < objectRight &&
	            entityBottom > objectTop && entityTop < objectBottom) {

	            object.onCollision(entity, this, (entity instanceof Entity));

	            float overlapX = Math.min(entityRight - objectLeft, objectRight - entityLeft);
	            float overlapY = Math.min(entityBottom - objectTop, objectBottom - entityTop);

	            if (overlapX < overlapY) {
	                if (entityRight - objectLeft < objectRight - entityLeft) {
	                    entity.x = (int) (objectLeft - entity.width);
	                } else {
	                    entity.x = (int) objectRight;
	                }
	            } else {
	                if (entityBottom - objectTop < objectBottom - entityTop) {
	                    entity.y = (int) (objectTop - entity.height);
	                    if (entity instanceof Entity) {
	                        ((Entity)entity).fallSpeed = 0;
	                    }
	                } else {
	                    entity.y = (int) objectBottom;
	                    if (entity instanceof Entity) {
	                        ((Entity)entity).fallSpeed = 0;
	                    }
	                }
	            }
	        }
	    }
	}

	
	public void render(Bitmap bitmap) {
		Bitmap worldBitmap = new Bitmap(bitmap.w, bitmap.h);
		worldBitmap.clear(bgColor);
		
		for (GameObject object : gObjects) {
			if (!object.isRemoved) {
				worldBitmap.draw(object.render(), object.x, object.y);
			}
		}
		
		for (Entity entity : entities) {
		    if (!entity.isRemoved) {
		    	worldBitmap.draw(entity.render(), entity.x, entity.y);
		    }
		}
		
		bitmap.draw(worldBitmap, 0, 0);
	}
}
