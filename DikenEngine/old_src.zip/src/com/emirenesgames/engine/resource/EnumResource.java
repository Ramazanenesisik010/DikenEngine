package com.emirenesgames.engine.resource;

public enum EnumResource {
	IMAGE
}
