package com.emirenesgames.engine.resource;

import java.awt.image.BufferedImage;
import java.io.InputStream;

import javax.imageio.ImageIO;

public class IOResource {
	
	public static final Bitmap missingTexture = generateMissingTexture();
	
	public static IResource loadResource(InputStream stream, EnumResource _enum) {
		if (_enum == EnumResource.IMAGE) {
			BufferedImage img = null;
			try {
				img = ImageIO.read(stream);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return toBitmap(img);
		}
		return null;
	}
	
	public static Bitmap[][] loadResourceAndCut(InputStream stream, int sw, int sh) {
		BufferedImage img = ((Bitmap)loadResource(stream, EnumResource.IMAGE)).toImage();
		
		int xSlices = img.getWidth() / sw;
	    int ySlices = img.getHeight() / sh;
	    Bitmap[][] result = new Bitmap[xSlices][ySlices];

	    for(int x = 0; x < xSlices; ++x) {
	    	for(int y = 0; y < ySlices; ++y) {
	        	result[x][y] = new Bitmap(sw, sh);
	        	img.getRGB(x * sw, y * sh, sw, sh, result[x][y].pixels, 0, sw);
	        }
	    }

	    return result;
	}

	private static Bitmap generateMissingTexture() {
		Bitmap bitmap = new Bitmap(16, 16);
		bitmap.fill(0, 0, 15, 15, 0xff000000);
		bitmap.fill(0, 8, 7, 15, 0xff76428a);
		bitmap.fill(8, 0, 15, 7, 0xff76428a);
		return bitmap;
	}
	
	public static Bitmap toBitmap(BufferedImage img) {
		if (img == null) {
			img = missingTexture.toImage();
		}
		   
		int sw = img.getWidth();
		int sh = img.getHeight();
		Bitmap result = new Bitmap(sw, sh);
		img.getRGB(0, 0, sw, sh, result.pixels, 0, sw);
		return result;
	}

}
